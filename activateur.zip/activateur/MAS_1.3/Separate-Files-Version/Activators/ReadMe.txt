----------------------------------------------------------------------------------------------
Activation Type       Supported Product             Activation Period
----------------------------------------------------------------------------------------------

Digital License    -  Windows 10                 -  Permanent
KMS38              -  Windows 10 / Server        -  Until the year 2038
Online KMS         -  Windows / Server / Office  -  For 180 Days, renewal task needs to be 
                                                    created for lifetime auto activation.

----------------------------------------------------------------------------------------------

* For more details, use the ReadMe.txt included in the respective activation folders.